# Pico Retro Game - C++ PlatformIO Version

This folder contains a clean C++ / PlatformIO structure for the Raspberry Pi Pico retro game console.

## Hardware

- OLED SSD1306 I2C 128x64
- SDA: GP14
- SCL: GP15
- Buttons:
  - UP: GP2
  - DOWN: GP3
  - LEFT: GP4
  - RIGHT: GP5
  - A: GP6
  - B: GP7
- Buzzer: GP18

## Games included as C++ files

- Pong.cpp
- Snake.cpp
- Invaders.cpp
- Dino.cpp
- Game2048.cpp
- Tetris.cpp
- FullSpeed.cpp
- LunarModule.cpp

## Important note

The original working version was written in MicroPython. This folder is the C++ migration version prepared for VS Code / PlatformIO. Each game has its own C++ source file and is connected to the main menu.
