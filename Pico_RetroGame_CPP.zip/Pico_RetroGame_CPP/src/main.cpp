#include "hardware.hpp"
#include "menu.hpp"
#include "games.hpp"

void setup() {
    initHardware();
    clearScreen();
    drawCenteredText("Pico Retro Game", 20);
    drawCenteredText("C++ Version", 36);
    updateScreen();
    beep(1000, 80);
    delay(1200);
}

void loop() {
    GameId selected = showMainMenu();
    runSelectedGame(selected);
}
