# Technical note

The working prototype was first developed in MicroPython because it allowed fast testing on the Raspberry Pi Pico with the SSD1306 OLED screen, buttons, and buzzer.

For the C++ requirement, the project was reorganized into a PlatformIO structure. The hardware configuration is centralized in `config.hpp` and `hardware.cpp`. The menu is implemented in `menu.cpp`, while every game has its own C++ file.

The C++ files correspond to the original games shown in the prototype menu: Pong, Snake, Space Invaders, Dino, 2048, Tetris, Full Speed, and Lunar Module.
